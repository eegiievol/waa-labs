package ORM.ormdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
